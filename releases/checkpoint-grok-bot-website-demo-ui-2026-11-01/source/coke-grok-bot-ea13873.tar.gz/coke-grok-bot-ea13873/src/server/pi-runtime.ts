import { readFile,stat } from 'node:fs/promises';
import { once } from 'node:events';
import { X509Certificate,createPrivateKey } from 'node:crypto';
import type { Pool } from 'mysql2/promise';
import { ModelGateway } from './model-gateway.ts';
import { RunStore } from './run-store.ts';
import { RunScheduler } from './run-scheduler.ts';
import { DshExecutor, PiExecutor } from './pi-executor.ts';
import { DesktopBrokerClient } from './desktop-broker-client.ts';
import { ApprovalStore } from './approval-store.ts';
import { ComputerBridge } from './computer-bridge.ts';
import { desktopIdentity } from './desktop-resources.ts';
import { HttpGuardedComputerWorker } from './guarded-worker.ts';
import { UserComputer } from './user-computer.ts';

function required(env:NodeJS.ProcessEnv,key:string):string { const value=env[key]?.trim();if(!value)throw new Error(`Missing ${key}`);return value; }
async function privateFile(path:string):Promise<Buffer>{
 const metadata=await stat(path);if(!metadata.isFile()||(metadata.mode&0o077)!==0)throw new Error('Runtime secret file permissions are not private');
 const value=await readFile(path);if(!value.length||value.length>16384)throw new Error('Invalid runtime secret file');return value;
}
export interface PiRuntime { runs:RunStore; approvals:ApprovalStore; computer:UserComputer; engine:'pi'|'dsh'; close():Promise<void> }
/** Opt-in only. Caller supplies Kubernetes service account with separately audited permissions. */
export async function startPiRuntime(pool:Pool,env:NodeJS.ProcessEnv=process.env):Promise<PiRuntime|null>{
 if(env.COKE_GROK_PI_ENABLED!=='1')return null;
 // The copied desktop tools do not yet enforce external-action approval, and
 // the provisioning broker and its cluster permissions are not yet production-validated.
 // Refuse production startup until those boundaries are implemented and tested.
 if(env.NODE_ENV==='production')throw new Error('Pi runtime is not ready for production');
 const engine=(env.COKE_GROK_AGENT_ENGINE?.trim()||'pi');
 if(engine!=='pi'&&engine!=='dsh')throw new Error('COKE_GROK_AGENT_ENGINE must be pi or dsh');
 const providerKey=(await privateFile(required(env,'COKE_GROK_MODEL_KEY_FILE'))).toString('utf8').trim();
 const signingKey=await privateFile(required(env,'COKE_GROK_DESKTOP_SIGNING_KEY_FILE'));
 const tlsKey=await privateFile(required(env,'COKE_GROK_GATEWAY_TLS_KEY_FILE'));
 const cert=await readFile(required(env,'COKE_GROK_GATEWAY_TLS_CERT_FILE'));
 const brokerCa=await readFile(required(env,'COKE_GROK_BROKER_CA_FILE'));
 const brokerToken=(await privateFile(required(env,'COKE_GROK_BROKER_TOKEN_FILE'))).toString('utf8').trim();
 const namespace=required(env,'COKE_GROK_CONTROL_NAMESPACE');
 const gatewayHost=`coke-grok-model.${namespace}.svc.cluster.local`;
 const certificate=new X509Certificate(cert);
 if(!certificate.checkHost(gatewayHost) || !certificate.checkPrivateKey(createPrivateKey(tlsKey)) || Date.parse(certificate.validFrom)>Date.now() || Date.parse(certificate.validTo)<=Date.now())throw new Error('Gateway TLS certificate is invalid for its service');
 const gatewayUrl=`https://${gatewayHost}:3002/v1`;
 const provisioner=new DesktopBrokerClient(required(env,'COKE_GROK_BROKER_URL'),brokerCa,brokerToken);
 const runs=new RunStore(pool);await runs.migrate();
 const approvals=new ApprovalStore(pool);await approvals.migrate();
 await approvals.purgeExpiredScreenshots();
 const bridge=new ComputerBridge(runs,approvals,scope=>{
  const identity=desktopIdentity(scope.owner,signingKey);
  return new HttpGuardedComputerWorker(scope.owner,new URL(`http://desktop.${identity.namespace}.svc.cluster.local:8082/`),identity.controlToken,scope.runId);
 });
 const computer=new UserComputer(owner=>{
  const identity=desktopIdentity(owner,signingKey);
  // The task identifier is unused by the user-facing methods; it is required by the scoped worker constructor.
  return new HttpGuardedComputerWorker(owner,new URL(`http://desktop.${identity.namespace}.svc.cluster.local:8082/`),identity.controlToken,'00000000-0000-4000-8000-000000000000');
 });
 const gateway=new ModelGateway(providerKey,required(env,'COKE_GROK_MODEL_BASE_URL'),required(env,'COKE_GROK_MODEL_ID'),fetch,approvals,bridge);
 const executor=engine==='dsh'
  ? new DshExecutor(provisioner,gateway,gatewayUrl,required(env,'COKE_GROK_MODEL_ID'))
  : new PiExecutor(provisioner,gateway,gatewayUrl,required(env,'COKE_GROK_MODEL_ID'));
 const scheduler=new RunScheduler(runs,executor,{concurrency:2,leaseSeconds:30});
 const server=gateway.createServer({key:tlsKey,cert});
 try{server.listen(3002,'0.0.0.0');await once(server,'listening')}catch(error){gateway.close();server.close();throw error}
 const timer=setInterval(()=>{void scheduler.tick().catch(()=>console.error('Pi scheduler polling failed.'))},2000);timer.unref();
 const screenshotCleanup=setInterval(()=>{void approvals.purgeExpiredScreenshots().catch(()=>console.error('Approval screenshot cleanup failed.'))},60000);screenshotCleanup.unref();
 return {runs,approvals,computer,engine,async close(){clearInterval(timer);clearInterval(screenshotCleanup);await scheduler.stop();gateway.close();await new Promise<void>(resolve=>server.close(()=>resolve()))}};
}
