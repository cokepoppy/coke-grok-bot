import test from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes, randomUUID } from 'node:crypto';
import { desktopIdentity, desktopResources, normalizeDesktopSigningKey, splitDesktopResources } from '../src/server/desktop-resources.ts';

test('desktop signing keys normalize trailing file whitespace before HMAC derivation',()=>{
 const tenantId=randomUUID(),userId=randomUUID(),normalized=Buffer.from('desktop-signing-key-'.repeat(3)),raw=Buffer.concat([normalized,Buffer.from('\n')]);
 assert.deepEqual(normalizeDesktopSigningKey(raw),normalized);
 assert.deepEqual(desktopIdentity({tenantId,userId},raw),desktopIdentity({tenantId,userId},normalized));
});

test('desktop signing key normalization preserves arbitrary binary bytes for Auth and Broker HMACs',()=>{
 const tenantId=randomUUID(),userId=randomUUID(),raw=Buffer.alloc(48,0xff),normalized=normalizeDesktopSigningKey(raw);
 assert.deepEqual(normalized,raw);
 assert.notDeepEqual(Buffer.from(raw.toString('utf8').trim(),'utf8'),raw);
 assert.deepEqual(desktopIdentity({tenantId,userId},raw),desktopIdentity({tenantId,userId},normalized));
});

test('desktop identities separate users and tenants and resources do not expose the provider key', () => {
 const signingKey=randomBytes(32), tenantId=randomUUID(), userId=randomUUID();
 const identity=desktopIdentity({tenantId,userId},signingKey);
 assert.deepEqual(desktopIdentity({tenantId,userId},signingKey),identity);
 assert.notEqual(desktopIdentity({tenantId,userId:randomUUID()},signingKey).namespace,identity.namespace);
 assert.notEqual(desktopIdentity({tenantId:randomUUID(),userId},signingKey).namespace,identity.namespace);
 assert.notEqual(identity.workerToken,identity.agentToken);
 assert.notEqual(identity.workerToken,identity.activeTabBridgeToken);
 assert.notEqual(identity.controlToken,identity.activeTabBridgeToken);
 assert.throws(()=>desktopIdentity({tenantId,userId},randomBytes(8)));
 const resources=desktopResources(identity,{image:`coke-grok-desktop:sha-${'a'.repeat(40)}`,controlNamespace:'coke-grok-bot',gatewayCA:'-----BEGIN CERTIFICATE-----\nTEST\n-----END CERTIFICATE-----'});
 const imagePin=resources.find(item=>item.kind==='ConfigMap'&&(item.metadata as {name:string}).name==='desktop-image-pin') as any;
 const deployment=resources.find(item=>item.kind==='Deployment') as any;
 const runtimeSecret=resources.find(item=>item.kind==='Secret'&&(item.metadata as {name:string}).name==='desktop-runtime') as any;
 const pod=deployment.spec.template.spec;
 assert.equal(pod.automountServiceAccountToken,false);
 assert.equal(pod.containers[0].securityContext.runAsUser,1000);
 assert.equal(pod.containers[1].securityContext.runAsUser,1001);
 assert.equal(pod.containers[1].securityContext.readOnlyRootFilesystem,true);
 assert.deepEqual(pod.containers[1].env.find((entry:any)=>entry.name==='DOTS_DESKTOP_AGENT_ADAPTERS').value.split(','),['pi','dsh']);
 assert.deepEqual(Object.keys(JSON.parse(pod.containers[1].env.find((entry:any)=>entry.name==='DOTS_AGENT_KERNELS_JSON').value)).sort(),['dsh','pi']);
 assert.equal(pod.containers[0].env.find((entry:any)=>entry.name==='COKE_DESKTOP_SCREEN_SLOTS').value,'8');
 assert.equal(pod.containers[0].env.find((entry:any)=>entry.name==='COKE_GROK_ACTIVE_TAB_BRIDGE_TOKEN').valueFrom.secretKeyRef.key,'activeTabBridge');
 assert.equal(runtimeSecret.stringData.activeTabBridge,identity.activeTabBridgeToken);
 assert.equal(imagePin.immutable,true);
 assert.deepEqual(imagePin.data,{desktopImage:`coke-grok-desktop:sha-${'a'.repeat(40)}`,agentImage:`coke-grok-desktop:sha-${'a'.repeat(40)}`});
 assert.equal(runtimeSecret.stringData.activeTabBridgeConfig,`self.COKE_GROK_ACTIVE_TAB_BRIDGE_TOKEN=${JSON.stringify(identity.activeTabBridgeToken)};`);
 assert.ok(pod.containers[0].volumeMounts.some((mount:any)=>mount.mountPath==='/opt/coke-grok/active-tab-extension/runtime-config.js'&&mount.subPath==='runtime-config.js'&&mount.readOnly));
 assert.equal(pod.volumes.find((volume:any)=>volume.name==='active-tab-bridge').secret.defaultMode,288);
 assert.equal(JSON.stringify(resources).includes('COKE_GROK_MODEL_KEY'),false);
 assert.throws(()=>desktopResources(identity,{image:'coke-grok-desktop:latest',controlNamespace:'coke-grok-bot',gatewayCA:'BEGIN CERTIFICATE'}));
});
test('experimental layout separates the Agent network from the desktop',()=>{
 const identity=desktopIdentity({tenantId:randomUUID(),userId:randomUUID()},randomBytes(32));
 const resources=splitDesktopResources(identity,{image:`coke-grok-desktop:sha-${'a'.repeat(40)}`,agentImage:`coke-grok-desktop:sha-${'b'.repeat(40)}`,controlNamespace:'coke-grok-bot',gatewayCA:'-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----'});
 const desktop=resources.find(item=>item.kind==='Deployment'&&(item.metadata as {name:string}).name==='desktop') as any;
 const agent=resources.find(item=>item.kind==='Deployment'&&(item.metadata as {name:string}).name==='agent') as any;
 assert.match(desktop.spec.template.spec.containers[0].image,/a{40}$/);
 assert.match(agent.spec.template.spec.containers[0].image,/b{40}$/);
 assert.deepEqual(desktop.spec.template.spec.containers.map((c:any)=>c.name),['desktop']);
 assert.deepEqual(agent.spec.template.spec.containers.map((c:any)=>c.name),['agent']);
 assert.equal(desktop.spec.template.spec.containers[0].securityContext.runAsUser,1000);
 assert.equal(agent.spec.template.spec.containers[0].securityContext.runAsUser,1001);
 assert.equal(agent.spec.template.spec.automountServiceAccountToken,false);
 assert.equal(agent.spec.template.spec.containers[0].env.some((entry:any)=>entry.name==='COKE_GROK_ACTIVE_TAB_BRIDGE_TOKEN'),false);
 const policy=resources.find(item=>item.kind==='NetworkPolicy'&&(item.metadata as {name:string}).name==='agent-isolation') as any;
 assert.equal(JSON.stringify(policy.spec.egress).includes('grok-desktop'),false);
 assert.equal((resources.find(item=>item.kind==='Service'&&(item.metadata as {name:string}).name==='desktop') as any).spec.ports.some((p:any)=>p.port===8083),false);
 assert.throws(()=>splitDesktopResources(identity,{image:'coke-grok-desktop:latest',agentImage:'coke-grok-desktop:latest',controlNamespace:'coke-grok-bot',gatewayCA:'-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----'}));
 assert.doesNotThrow(()=>splitDesktopResources(identity,{image:'coke-grok-desktop:candidate-gmail-approval-20261107-r1',agentImage:'coke-grok-desktop:candidate-gmail-approval-20261107-r1',controlNamespace:'coke-grok-bot',gatewayCA:'-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----'}));
});
test('desktop Google proxy is explicit, host-scoped, and available only to Chromium',()=>{
 const identity=desktopIdentity({tenantId:randomUUID(),userId:randomUUID()},randomBytes(32)),options={image:`coke-grok-desktop:sha-${'a'.repeat(40)}`,controlNamespace:'coke-grok-bot',gatewayCA:'-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----',desktopProxyServer:'http://host.docker.internal:17891',desktopProxyHostIp:'192.168.65.254'};
 const resources=splitDesktopResources(identity,options),desktop=resources.find(item=>item.kind==='Deployment'&&(item.metadata as {name:string}).name==='desktop') as any,agent=resources.find(item=>item.kind==='Deployment'&&(item.metadata as {name:string}).name==='agent') as any,desktopPolicy=resources.find(item=>item.kind==='NetworkPolicy'&&(item.metadata as {name:string}).name==='desktop-isolation') as any;
 assert.equal(desktop.spec.template.spec.containers[0].env.find((entry:any)=>entry.name==='COKE_DESKTOP_PROXY_SERVER').value,options.desktopProxyServer);
 assert.equal(agent.spec.template.spec.containers[0].env.some((entry:any)=>entry.name==='COKE_DESKTOP_PROXY_SERVER'),false);
 const publicEgress=desktopPolicy.spec.egress.find((rule:any)=>rule.to?.some((target:any)=>target.ipBlock?.cidr==='0.0.0.0/0'));
 assert.ok(publicEgress);
 assert.equal('ports' in publicEgress,false);
 assert.deepEqual(publicEgress.to[0].ipBlock.except,['10.0.0.0/8','172.16.0.0/12','192.168.0.0/16','169.254.0.0/16','127.0.0.0/8']);
 assert.ok(desktopPolicy.spec.egress.some((rule:any)=>rule.to?.some((target:any)=>target.ipBlock?.cidr==='192.168.65.254/32')&&rule.ports?.some((port:any)=>port.protocol==='TCP'&&port.port===17891)));
 assert.throws(()=>splitDesktopResources(identity,{...options,desktopProxyServer:'http://host.docker.internal:7890'}));
 assert.throws(()=>splitDesktopResources(identity,{...options,desktopProxyHostIp:'0.0.0.0'}));
});
