/** Real Pi, isolated desktop, test-user approval and model. Never logs credentials. */
import {spawn} from 'node:child_process';
import {request as httpRequest,type IncomingMessage} from 'node:http';
import {randomBytes,randomUUID,createHash} from 'node:crypto';
import {mkdtemp,readFile,rm,writeFile} from 'node:fs/promises';
import {once} from 'node:events';
import {Readable} from 'node:stream';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {createServer as netServer} from 'node:net';
import assert from 'node:assert/strict';
import mysql from 'mysql2/promise';
import {chromium,type Browser,type Page} from 'playwright-core';
import {TenantStore} from '../src/server/tenant-store.ts';
import {BotStore} from '../src/server/bot-store.ts';
import {RunStore} from '../src/server/run-store.ts';
import {ApprovalStore} from '../src/server/approval-store.ts';
import {BotMemoryStore} from '../src/server/bot-memory-store.ts';
import {BotMemoryBridge} from '../src/server/bot-memory-bridge.ts';
import {RunScheduler} from '../src/server/run-scheduler.ts';
import {DshExecutor,PiExecutor} from '../src/server/pi-executor.ts';
import {ModelGateway} from '../src/server/model-gateway.ts';
import {ComputerBridge} from '../src/server/computer-bridge.ts';
import {HttpGuardedComputerWorker} from '../src/server/guarded-worker.ts';
import {desktopIdentity,splitDesktopResources} from '../src/server/desktop-resources.ts';
import {GoogleAuthService,type IdentityProvider} from '../src/server/google-auth.ts';
import {createAuthServer} from '../src/server/auth-http.ts';
import {UserComputer} from '../src/server/user-computer.ts';
import {WorkspaceFileTransport} from '../src/server/workspace-file-client.ts';
import {WorkspaceFileStore,type RunFile} from '../src/server/file-store.ts';
import {GroupChatStore} from '../src/server/group-chat-store.ts';
const mysqlPort=Number(process.env.COKE_GROK_TEST_MYSQL_PORT),keyFile=process.env.COKE_GROK_MODEL_KEY_FILE,image=process.env.COKE_GROK_DESKTOP_TEST_IMAGE;
const memoryOnly=process.argv.includes('--memory-only');
const gmailHandoffOnly=process.argv.includes('--gmail-handoff-only');
const computerUiOnly=process.argv.includes('--computer-ui-only');
const singleGmailHandoffRun=process.argv.includes('--single-gmail-handoff-run');
const desktopSourceOverlay=process.env.COKE_GROK_DESKTOP_TEST_SOURCE_OVERLAY!=='0';
const modelBaseUrl=process.env.COKE_GROK_TEST_MODEL_BASE_URL||'https://api.deepseek.com';
const modelId=process.env.COKE_GROK_TEST_MODEL_ID||'deepseek-flash';
if(!mysqlPort||(!keyFile&&!computerUiOnly)||!image)throw new Error('Disposable MySQL, private model key (unless running the UI-only mode) and pinned desktop image required');
const modelKey=keyFile?(await readFile(keyFile,'utf8')).trim():'ui-only-no-model-call';
const safeDiagnostic=(value:string)=>value.replaceAll(modelKey,'[redacted]').replace(/\bsk-[A-Za-z0-9_-]{8,}\b/g,'[redacted-api-key]').replace(/\b[A-Za-z0-9_-]{43}\b/g,'[redacted-token]').replace(/(authorization\s*:\s*bearer\s+)\S+/ig,'$1[redacted]').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g,' ').slice(0,500);
const dir=await mkdtemp(join(tmpdir(),'grok-mediated-pi-')),db=`grok_mediated_${randomUUID().replaceAll('-','')}`;
let namespace='',desktopPodName='',namespaceCreated=false,dbCreated=false,admin:mysql.Connection|undefined,pool:mysql.Pool|undefined,server:import('node:http').Server|undefined,gatewayServer:import('node:http').Server|undefined,gateway:ModelGateway|undefined,scheduler:RunScheduler|undefined;
const forwards:import('node:child_process').ChildProcess[]=[];let modelCalls=0,agentAdapterDiagnostic='';let userControlBrowser:Awaited<ReturnType<typeof chromium.launch>>|undefined,desktopObserver:Browser|undefined;const workerFailures:Array<{path:string;status:number;code?:string;message?:string;kind?:string;action?:string;destinationHost?:string}>=[];
let dshComputerScreenshots=0,dshComputerInspections=0;
async function exec(command:string,args:string[],input?:string,timeout=120_000){const child=spawn(command,args,{stdio:['pipe','pipe','pipe']});let out='',err='';child.stdout.setEncoding('utf8');child.stdout.on('data',c=>{out=(out+c).slice(-100000)});child.stderr.setEncoding('utf8');child.stderr.on('data',c=>{err=(err+c).slice(-100000)});child.stdin.end(input);const timer=setTimeout(()=>child.kill('SIGKILL'),timeout);try{const [code]=await once(child,'close') as [number|null];return {code:code??1,out,err}}finally{clearTimeout(timer)}}
async function run(command:string,args:string[],input?:string,timeout?:number){const result=await exec(command,args,input,timeout);if(result.code!==0)throw new Error(`${command} test operation failed: ${safeDiagnostic(result.err||result.out)}`);return result.out}
async function portForward(name:string,target:number,resource='service'){const child=spawn('kubectl',['-n',namespace,'port-forward',`${resource}/${name}`,`:${target}`],{stdio:['ignore','pipe','pipe']});forwards.push(child);child.stderr!.resume();return new Promise<number>((resolve,reject)=>{let out='';child.stdout!.on('data',c=>{out+=String(c);const m=out.match(new RegExp(`127\\.0\\.0\\.1:(\\d+) -> ${target}`));if(m)resolve(Number(m[1]))});child.once('exit',()=>reject(new Error('Port-forward exited')));setTimeout(()=>reject(new Error('Port-forward timeout')),15000).unref()})}
const sleep=(ms:number)=>new Promise(resolve=>setTimeout(resolve,ms));
try{
 assert.equal((await run('kubectl',['config','current-context'])).trim(),'k3d-tp1121-sandbox-dev');
 admin=await mysql.createConnection({host:'127.0.0.1',port:mysqlPort,user:'root'});await admin.query(`CREATE DATABASE \`${db}\``);dbCreated=true;pool=mysql.createPool({host:'127.0.0.1',port:mysqlPort,user:'root',database:db,timezone:'Z',connectionLimit:10});
 const ids=new TenantStore(pool),bots=new BotStore(pool),runs=new RunStore(pool),approvals=new ApprovalStore(pool),memories=new BotMemoryStore(pool),files=new WorkspaceFileStore(pool),groups=new GroupChatStore(pool);await ids.migrate();await bots.migrate();await runs.migrate();await approvals.migrate();await memories.migrate();await files.migrate();await groups.migrate();
 const owner=await ids.signInGoogle({subject:'mediated-owner',email:'mediated@example.test',name:'Mediated Owner'}),session={...owner,email:'mediated@example.test',name:'Mediated Owner',role:'owner'},bot=await bots.create(session,{name:'Mediated Bot',color:'#abcdef',shape:'round'});
 const cookie=randomBytes(32).toString('base64url');await ids.createSession(createHash('sha256').update(cookie).digest('hex'),owner.userId,owner.tenantId,new Date(Date.now()+600_000));
 const identity=desktopIdentity(owner,randomBytes(32));namespace=identity.namespace;
 const cert=join(dir,'cert.pem'),key=join(dir,'key.pem');await run('openssl',['req','-x509','-newkey','rsa:2048','-nodes','-keyout',key,'-out',cert,'-days','1','-subj','/CN=host.k3d.internal','-addext','subjectAltName=DNS:host.k3d.internal']);
 let workerPort=0,vncPort=0,cdpPort=0;const workerTransport:typeof fetch=async(url,init)=>{const path=new URL(String(url)).pathname,response=await fetch(`http://127.0.0.1:${workerPort}${path}`,init);if(!response.ok){const body=await response.clone().json().catch(()=>null) as {code?:unknown;error?:unknown}|null;let action:{kind?:unknown;action?:unknown;url?:unknown}|undefined;try{action=JSON.parse(String(init?.body||'')).action}catch{}let destinationHost:string|undefined;try{if(typeof action?.url==='string')destinationHost=new URL(action.url).hostname}catch{}workerFailures.push({path,status:response.status,...(typeof body?.code==='string'?{code:body.code}:{}),...(typeof body?.error==='string'?{message:safeDiagnostic(body.error.replace(/https?:\/\/\S+/g,'[url]'))}:{}),...(typeof action?.kind==='string'?{kind:action.kind}:{}),...(typeof action?.action==='string'?{action:action.action}:{}),...(destinationHost?{destinationHost}:{})});}return response};
 const bridge=new ComputerBridge(runs,approvals,scope=>new HttpGuardedComputerWorker(scope.owner,scope.botId,new URL(`http://desktop.${namespace}.svc.cluster.local:8082/`),identity.controlToken,scope.runId,workerTransport));
 const captureScreenshot=bridge.screenshot.bind(bridge),inspectComputer=bridge.inspect.bind(bridge);
 bridge.screenshot=async(...args:Parameters<typeof bridge.screenshot>)=>{dshComputerScreenshots++;return captureScreenshot(...args)};
 bridge.inspect=async(...args:Parameters<typeof bridge.inspect>)=>{dshComputerInspections++;return inspectComputer(...args)};
 const memoryBridge=new BotMemoryBridge(memories),memoryCalls={list:0,remember:0,forget:0};
 const memoryList=memoryBridge.list.bind(memoryBridge),memoryRemember=memoryBridge.remember.bind(memoryBridge),memoryForget=memoryBridge.forget.bind(memoryBridge);
 memoryBridge.list=async(...args:Parameters<typeof memoryBridge.list>)=>{memoryCalls.list++;return memoryList(...args)};
 memoryBridge.remember=async(...args:Parameters<typeof memoryBridge.remember>)=>{memoryCalls.remember++;return memoryRemember(...args)};
 memoryBridge.forget=async(...args:Parameters<typeof memoryBridge.forget>)=>{memoryCalls.forget++;return memoryForget(...args)};
 gateway=new ModelGateway(modelKey,modelBaseUrl,modelId,async(url,init)=>{modelCalls++;return fetch(url,init)},approvals,bridge,memoryBridge);
 gatewayServer=gateway.createServer({key:await readFile(key),cert:await readFile(cert)});gatewayServer.listen(0,'0.0.0.0');await once(gatewayServer,'listening');const gatewayAddr=gatewayServer.address();if(!gatewayAddr||typeof gatewayAddr==='string')throw new Error('No gateway port');
 const resources=splitDesktopResources(identity,{image,controlNamespace:'coke-grok-bot',gatewayCA:await readFile(cert,'utf8'),...(gmailHandoffOnly?{desktopProxyServer:'http://host.docker.internal:17891',desktopProxyHostIp:'192.168.65.254'}:{})});
 const sourceOverlayName='computer-worker-source',activeTabExtensionName='active-tab-extension-source',desktopDeployment=resources.find(x=>x.kind==='Deployment'&&(x.metadata as {name:string}).name==='desktop') as any,desktopPodSpec=desktopDeployment.spec.template.spec,desktopContainer=desktopPodSpec.containers.find((container:any)=>container.name==='desktop');assert.ok(desktopContainer,'The isolated desktop Deployment must contain its desktop worker');
 if(desktopSourceOverlay){desktopPodSpec.volumes=desktopPodSpec.volumes.filter((volume:any)=>volume.name!=='active-tab-bridge');desktopContainer.volumeMounts=desktopContainer.volumeMounts.filter((mount:any)=>mount.name!=='active-tab-bridge');desktopPodSpec.volumes.push({name:sourceOverlayName,configMap:{name:sourceOverlayName,defaultMode:493}},{name:activeTabExtensionName,projected:{sources:[{configMap:{name:activeTabExtensionName}},{secret:{name:'desktop-runtime',items:[{key:'activeTabBridgeConfig',path:'runtime-config.js'}]}}],defaultMode:288}});desktopContainer.volumeMounts.unshift({name:activeTabExtensionName,mountPath:'/opt/coke-grok/active-tab-extension',readOnly:true});desktopContainer.volumeMounts.push({name:sourceOverlayName,mountPath:'/usr/local/bin/start-grok-desktop',subPath:'start-desktop.sh',readOnly:true},{name:sourceOverlayName,mountPath:'/opt/coke-dots/desktop-input.mjs',subPath:'desktop-input.mjs',readOnly:true},{name:sourceOverlayName,mountPath:'/opt/coke-dots/grok-computer-worker.mjs',subPath:'grok-computer-worker.mjs',readOnly:true},{name:sourceOverlayName,mountPath:'/opt/coke-dots/bot-screen-pages.mjs',subPath:'bot-screen-pages.mjs',readOnly:true},{name:sourceOverlayName,mountPath:'/opt/coke-grok/guarded-computer.mjs',subPath:'guarded-computer.mjs',readOnly:true});}
 const sourceOverlay=desktopSourceOverlay?{apiVersion:'v1',kind:'ConfigMap',metadata:{name:sourceOverlayName,namespace,labels:{'app.kubernetes.io/managed-by':'coke-grok-bot','coke-grok-bot.io/owner-hash':identity.ownerHash}},data:{'start-desktop.sh':await readFile('deploy/desktop/start-desktop.sh','utf8'),'desktop-input.mjs':await readFile('deploy/desktop/desktop-input.mjs','utf8'),'grok-computer-worker.mjs':await readFile('deploy/desktop/computer-worker.mjs','utf8'),'bot-screen-pages.mjs':await readFile('deploy/desktop/bot-screen-pages.mjs','utf8'),'guarded-computer.mjs':await readFile('deploy/desktop/guarded-computer.mjs','utf8')}}:undefined;
 const activeTabExtensionOverlay=desktopSourceOverlay?{apiVersion:'v1',kind:'ConfigMap',metadata:{name:activeTabExtensionName,namespace,labels:{'app.kubernetes.io/managed-by':'coke-grok-bot','coke-grok-bot.io/owner-hash':identity.ownerHash}},data:{'manifest.json':await readFile('deploy/desktop/active-tab-extension/manifest.json','utf8'),'service-worker.js':await readFile('deploy/desktop/active-tab-extension/service-worker.js','utf8')}}:undefined;
 const agentDeployment=resources.find(x=>x.kind==='Deployment'&&(x.metadata as {name:string}).name==='agent') as any;agentDeployment.spec.template.spec.hostAliases=[{ip:'192.168.65.254',hostnames:['host.k3d.internal']}];
 const agentKernelOverlayName='agent-kernel-adapter-source',agentContainer=agentDeployment.spec.template.spec.containers.find((container:any)=>container.name==='agent');assert.ok(agentContainer,'The isolated Agent Deployment must contain its Agent runtime');
 const agentKernelOverlay=gmailHandoffOnly?{apiVersion:'v1',kind:'ConfigMap',metadata:{name:agentKernelOverlayName,namespace,labels:{'app.kubernetes.io/managed-by':'coke-grok-bot','coke-grok-bot.io/owner-hash':identity.ownerHash}},data:{'grok-kernel-adapter.mjs':await readFile('deploy/desktop/cloud-kernel-adapter.mjs','utf8')}}:undefined;
 if(agentKernelOverlay){agentDeployment.spec.template.spec.volumes.push({name:agentKernelOverlayName,configMap:{name:agentKernelOverlayName,defaultMode:292}});agentContainer.volumeMounts.push({name:agentKernelOverlayName,mountPath:'/opt/coke-dots/grok-kernel-adapter.mjs',subPath:'grok-kernel-adapter.mjs',readOnly:true})}
 const agentPolicy=resources.find(x=>x.kind==='NetworkPolicy'&&(x.metadata as {name:string}).name==='agent-isolation') as any;agentPolicy.spec.egress.push({to:[{ipBlock:{cidr:'192.168.65.254/32'}}],ports:[{protocol:'TCP',port:gatewayAddr.port}]});
 await run('kubectl',['create','-f','-'],JSON.stringify(resources[0]));namespaceCreated=true;if(sourceOverlay)await run('kubectl',['create','-f','-'],JSON.stringify(sourceOverlay));if(activeTabExtensionOverlay)await run('kubectl',['create','-f','-'],JSON.stringify(activeTabExtensionOverlay));if(agentKernelOverlay)await run('kubectl',['create','-f','-'],JSON.stringify(agentKernelOverlay));await run('kubectl',['create','-f','-'],JSON.stringify({apiVersion:'v1',kind:'List',items:resources.slice(1)}));
 await run('kubectl',['-n',namespace,'rollout','status','deployment/agent','--timeout=150s'],undefined,160_000);await run('kubectl',['-n',namespace,'rollout','status','deployment/desktop','--timeout=150s'],undefined,160_000);
 const pod=(await run('kubectl',['-n',namespace,'get','pods','-l','app=grok-agent','-o','jsonpath={.items[0].metadata.name}'])).trim();desktopPodName=(await run('kubectl',['-n',namespace,'get','pods','-l','app=grok-desktop','-o','jsonpath={.items[0].metadata.name}'])).trim();workerPort=await portForward('desktop',8082);cdpPort=await portForward(desktopPodName,9222,'pod');const agentPort=await portForward('agent',8083);if(gmailHandoffOnly)vncPort=await portForward('desktop',6080);
 const workspaceTransport=new WorkspaceFileTransport({connect:async()=>({agentUrl:new URL(`http://agent.${namespace}.svc.cluster.local:8083/`),agentToken:identity.agentToken})},((url:string|URL,options:Parameters<typeof httpRequest>[1],callback:Parameters<typeof httpRequest>[2])=>{const source=new URL(String(url)),target=new URL(`${source.pathname}${source.search}`,`http://127.0.0.1:${agentPort}`);return httpRequest(target,options,callback)}) as typeof httpRequest);
 const uploadedFileId=randomUUID(),uploadedBytes=Buffer.from('GROK_K3D_WORKSPACE_UPLOAD_OK');
 const uploadReceipt=await workspaceTransport.upload(session,{id:uploadedFileId,extension:'txt',mimeType:'text/plain',size:uploadedBytes.length,body:Readable.from([uploadedBytes]) as unknown as IncomingMessage},AbortSignal.timeout(60_000));
 assert.deepEqual(uploadReceipt,{size:uploadedBytes.length,sha256:createHash('sha256').update(uploadedBytes).digest('hex')},'Workspace upload must persist exact bytes in the real K3D Agent workspace');
 const downloadedFile=await workspaceTransport.download(session,`shared/uploads/${uploadedFileId}.txt`,AbortSignal.timeout(60_000)),downloadedChunks:Buffer[]=[];
 for await(const chunk of downloadedFile.body)downloadedChunks.push(Buffer.from(chunk));
 assert.equal(downloadedFile.size,uploadedBytes.length);assert.deepEqual(Buffer.concat(downloadedChunks),uploadedBytes,'Workspace download must return the exact uploaded K3D bytes');
 await workspaceTransport.removeUpload(session,uploadedFileId,'txt',AbortSignal.timeout(30_000));
 const reserve=netServer();reserve.listen(0,'127.0.0.1');await once(reserve,'listening');const apiPort=(reserve.address() as import('node:net').AddressInfo).port;await new Promise<void>(resolve=>reserve.close(()=>resolve()));const origin=`http://127.0.0.1:${apiPort}`,base=origin+'/grok-bot',provider:IdentityProvider={authorizationUrl:()=>'',exchange:async()=>({})};
 const userComputer=new UserComputer((scope,botId)=>new HttpGuardedComputerWorker(scope,botId,new URL(`http://desktop.${namespace}.svc.cluster.local:8082/`),identity.controlToken,randomUUID(),workerTransport));
 if(gmailHandoffOnly){const originalVncEndpoint=userComputer.vncEndpoint.bind(userComputer);userComputer.vncEndpoint=async(...args)=>{const endpoint=await originalVncEndpoint(...args);return endpoint?new URL(`http://127.0.0.1:${vncPort}/`):null}}
 server=createAuthServer(new GoogleAuthService(ids,provider,base),base,gmailHandoffOnly?'dist':undefined,bots,runs,approvals,userComputer,'pi',files,workspaceTransport,groups);server.listen(apiPort,'127.0.0.1');await once(server,'listening');
 const apiCookie=`coke_grok_session=${cookie}`,path=`${base}/api/bots/${bot.id}/runs`,requestId=randomUUID();
 const submitRun=async(botId:string,prompt:string)=>{const response=await fetch(`${base}/api/bots/${botId}/runs`,{method:'POST',headers:{cookie:apiCookie,origin,'content-type':'application/json'},body:JSON.stringify({requestId:randomUUID(),prompt})});assert.equal(response.status,200);return (await response.json() as {run:{id:string}}).run};
 const workerRequest=(workerPath:string,body?:unknown)=>fetch(`http://127.0.0.1:${workerPort}${workerPath}`,{method:body===undefined?'GET':'POST',headers:{authorization:`Bearer ${identity.controlToken}`,'x-coke-grok-screen-id':bot.id,...(body===undefined?{}:{'content-type':'application/json'})},...(body===undefined?{}:{body:JSON.stringify(body)})});
 const awaitRun=async(botId:string,runId:string)=>{const url=`${base}/api/bots/${botId}/runs`;for(let i=0;i<240;i++){const response=await fetch(url,{headers:{cookie:apiCookie}}),rows=(await response.json() as {runs:{id:string;status:string;result:string|null}[]}).runs,found=rows.find(value=>value.id===runId);assert.ok(found);if(found.status==='completed')return found;if(found.status==='failed'||found.status==='unknown')throw new Error(`Memory E2E task ended ${found.status}; resultLength=${found.result?.length||0}; memoryCalls=${JSON.stringify(memoryCalls)}`);await sleep(1000)}throw new Error(`Memory E2E task timed out; memoryCalls=${JSON.stringify(memoryCalls)}`)};
 const userPost=(route:string,body:unknown)=>fetch(`${base}/api/bots/${bot.id}/computer/${route}`,{method:'POST',headers:{cookie:apiCookie,origin,'content-type':'application/json'},body:JSON.stringify(body)});
 const groupBuddy=await bots.create(session,{name:'Attachment Buddy',color:'#abcdef',shape:'round'});
 const groupResponse=await fetch(`${base}/api/groups`,{method:'POST',headers:{cookie:apiCookie,origin,'content-type':'application/json'},body:JSON.stringify({requestId:randomUUID(),name:'K3D Attachment E2E',botIds:[bot.id,groupBuddy.id]})});assert.equal(groupResponse.status,201);
 const testGroup=(await groupResponse.json() as {group:{id:string}}).group;
 const uploadBytes=Buffer.from('GROK_K3D_GROUP_ATTACHMENT_OK');
 const uploadResponse=await fetch(`${base}/api/groups/${testGroup.id}/files`,{method:'POST',headers:{cookie:apiCookie,origin,'content-type':'text/plain','content-length':String(uploadBytes.length),'x-file-name':encodeURIComponent('k3d-attachment.txt')},body:uploadBytes});assert.equal(uploadResponse.status,201);
 const uploadedGroupFile=(await uploadResponse.json() as {file:{id:string;size:number;sha256:string;kind:string}}).file;
 assert.equal(uploadedGroupFile.size,uploadBytes.length);assert.equal(uploadedGroupFile.sha256,createHash('sha256').update(uploadBytes).digest('hex'));assert.equal(uploadedGroupFile.kind,'input');
 const storedGroupFile=await groups.fileForDownload(session,uploadedGroupFile.id);assert.ok(storedGroupFile);assert.equal(storedGroupFile.storageKey,`shared/uploads/${uploadedGroupFile.id}.txt`);
 const groupDownload=await workspaceTransport.download(session,storedGroupFile.storageKey,AbortSignal.timeout(60_000)),groupDownloadChunks:Buffer[]=[];for await(const chunk of groupDownload.body)groupDownloadChunks.push(Buffer.from(chunk));assert.deepEqual(Buffer.concat(groupDownloadChunks),uploadBytes,'Authenticated group upload must place exact bytes in the K3D workspace');
 const wrongGroupResponse=await fetch(`${base}/api/groups`,{method:'POST',headers:{cookie:apiCookie,origin,'content-type':'application/json'},body:JSON.stringify({requestId:randomUUID(),name:'Other K3D Group',botIds:[bot.id,groupBuddy.id]})});assert.equal(wrongGroupResponse.status,201);
 const wrongGroup=(await wrongGroupResponse.json() as {group:{id:string}}).group;
 const wrongScopeResponse=await fetch(`${base}/api/groups/${wrongGroup.id}/messages`,{method:'POST',headers:{cookie:apiCookie,origin,'content-type':'application/json'},body:JSON.stringify({requestId:randomUUID(),text:'Must reject a file from another group.',targetBotIds:[bot.id],files:[uploadedGroupFile.id]})});assert.equal(wrongScopeResponse.status,400,'A group must not attach a file uploaded for a different group');
 const piRequest:typeof fetch=async(url,init)=>{const response=await fetch(`http://127.0.0.1:${agentPort}${new URL(String(url)).pathname}`,init);if(!response.ok){const value=await response.clone().json().catch(()=>null) as {error?:unknown}|null;if(typeof value?.error==='string')agentAdapterDiagnostic=safeDiagnostic(value.error).slice(0,600)}return response};
 const executor=new PiExecutor({connect:async()=>({agentUrl:new URL(`http://agent.${namespace}.svc.cluster.local:8083/`),agentToken:identity.agentToken})},gateway,`https://host.k3d.internal:${gatewayAddr.port}/v1`,modelId,piRequest,memories);
 const dshRequest:typeof fetch=async(url,init)=>fetch(`http://127.0.0.1:${agentPort}${new URL(String(url)).pathname}`,init);
 const dshExecutor=new DshExecutor({connect:async()=>({agentUrl:new URL(`http://agent.${namespace}.svc.cluster.local:8083/`),agentToken:identity.agentToken})},gateway,`https://host.k3d.internal:${gatewayAddr.port}/v1`,modelId,dshRequest,memories);
 if(gmailHandoffOnly){
  userControlBrowser=await chromium.launch({headless:true,executablePath:process.env.CHROME_BIN||'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});
  const controlContext=await userControlBrowser.newContext({viewport:{width:1440,height:900}}),controlPage=await controlContext.newPage(),uiErrors:string[]=[];controlPage.on('pageerror',error=>uiErrors.push(error.message));controlPage.on('console',message=>{if(message.type()==='error')uiErrors.push(message.text())});let typingIntoAddressBar=false;const screenshotPollsDuringTyping:string[]=[];controlPage.on('requestfinished',request=>{if(!typingIntoAddressBar)return;const pathname=new URL(request.url()).pathname;if(pathname.endsWith(`/api/bots/${bot.id}/computer/screenshot`))screenshotPollsDuringTyping.push(request.url())});await controlContext.addCookies([{name:'coke_grok_session',value:cookie,url:`${origin}/grok-bot/`}]);
  await controlContext.addInitScript(()=>{const frameWindow=window as (Window&{__cokeRfbFrames?:number[][]}),originalSend=WebSocket.prototype.send;WebSocket.prototype.send=function(data){let bytes:Uint8Array|undefined;if(data instanceof ArrayBuffer)bytes=new Uint8Array(data);else if(ArrayBuffer.isView(data))bytes=new Uint8Array(data.buffer,data.byteOffset,data.byteLength);if(bytes&&(bytes[0]===4||bytes[0]===5))(frameWindow.__cokeRfbFrames||=[]).push(Array.from(bytes.slice(0,8)));return originalSend.call(this,data)}});
  await controlPage.goto(`${base}/`);await controlPage.locator(`[data-bot-id="${bot.id}"]`).click();const messageField=controlPage.getByLabel(`Message ${bot.name}`);await messageField.waitFor();
  const submitFromComposer=async(prompt:string)=>{await messageField.fill(prompt);const responsePromise=controlPage.waitForResponse(response=>response.request().method()==='POST'&&response.url().endsWith(`/api/bots/${bot.id}/runs`));await controlPage.getByRole('button',{name:'Send task'}).click();const response=await responsePromise;assert.equal(response.status(),200,`Product composer must create a run successfully: ${response.status()}`);return (await response.json() as {run:{id:string}}).run};
  if(!computerUiOnly){
   scheduler=new RunScheduler(runs,executor,{concurrency:1,leaseSeconds:30});
   const publicRequestPrompt="For this read-only public end-to-end check, use Browser User on this Bot's cloud computer to open https://mail.google.com and stop at the first sign-in page so I can take control. Do not use Desktop User, click anything, enter credentials, or submit a form.";
   const prompt=singleGmailHandoffRun?publicRequestPrompt:'帮我打开谷歌，然后登录我的 Gmail，然后你在登录的时候停下来，让我去操作。在云电脑里面打开 Chrome 浏览器。';
   const task=await submitFromComposer(prompt);await scheduler.tick();let status='',approvalCount=-1,result='';
   for(let i=0;i<240;i++){
    const response=await fetch(path,{headers:{cookie:apiCookie}}),rows=(await response.json() as {runs:{id:string;status:string;result:string|null}[]}).runs,found=rows.find(value=>value.id===task.id);assert.ok(found);status=found.status;result=found.result||'';
    const approvalResponse=await fetch(`${base}/api/runs/${task.id}/approvals`,{headers:{cookie:apiCookie}}),approvalData=await approvalResponse.json() as {approvals:{id:string;status:string}[]};approvalCount=approvalData.approvals.length;
    if(approvalCount>0){const actions=approvalData.approvals.map(item=>{try{const value=JSON.parse(item.action) as {kind?:unknown;action?:unknown;arguments?:{url?:unknown}};let origin:string|undefined;try{if(typeof value.arguments?.url==='string')origin=new URL(value.arguments.url).origin}catch{}return {status:item.status,kind:value.kind,action:value.action,...(origin?{origin}:{})}}catch{return {status:item.status}}});throw new Error(`Gmail sign-in handoff created ${approvalCount} approval card(s): ${JSON.stringify(actions)}; workerFailures=${JSON.stringify(workerFailures.slice(-8))}`)}
    if(['completed','failed','unknown'].includes(status))break;
    await sleep(1000);
   }
   if(status!=='completed')throw new Error(`Real DeepSeek Pi Gmail handoff did not complete safely: ${status}; approvals=${approvalCount}; modelCalls=${modelCalls}; workerFailures=${JSON.stringify(workerFailures.slice(-8))}; agentDiagnostic=${JSON.stringify(agentAdapterDiagnostic)}; result=${safeDiagnostic(result)}`);
   await controlPage.locator('.conversation').getByText(prompt,{exact:true}).waitFor();assert.equal(await controlPage.locator('.approval-card').count(),0,'The real product conversation must not render a repeated-approval card for the Gmail handoff');
   const [runRows]=await pool.execute('SELECT status,computer_used AS computerUsed FROM agent_runs WHERE id=?',[task.id]) as [Array<{status:string;computerUsed:number|boolean}>,unknown];
   assert.equal(runRows[0]?.status,'completed');assert.ok(Boolean(runRows[0]?.computerUsed),'The model must actually use the isolated K3D computer');assert.ok(modelCalls>0,'The run must call the configured DeepSeek API');
   if(!singleGmailHandoffRun){
    const followupPrompt='不需要我的批准呢，你直接去打开它，你不要每步都让我批准。',followup=await submitFromComposer(followupPrompt);await scheduler.tick();let followupStatus='',followupResult='';
    for(let i=0;i<240;i++){
     const response=await fetch(path,{headers:{cookie:apiCookie}}),rows=(await response.json() as {runs:{id:string;status:string;result:string|null}[]}).runs,found=rows.find(value=>value.id===followup.id);assert.ok(found);followupStatus=found.status;followupResult=found.result||'';
     const approvalResponse=await fetch(`${base}/api/runs/${followup.id}/approvals`,{headers:{cookie:apiCookie}}),approvalData=await approvalResponse.json() as {approvals:{id:string;status:string}[]};
     if(approvalData.approvals.length)throw new Error(`Gmail approval follow-up created ${approvalData.approvals.length} approval card(s); workerFailures=${JSON.stringify(workerFailures.slice(-8))}`);
     if(['completed','failed','unknown'].includes(followupStatus))break;await sleep(1000);
    }
    if(followupStatus!=='completed')throw new Error(`DeepSeek Gmail approval follow-up did not complete safely: ${followupStatus}; modelCalls=${modelCalls}; workerFailures=${JSON.stringify(workerFailures.slice(-8))}; result=${safeDiagnostic(followupResult)}`);
    await controlPage.locator('.conversation').getByText(followupPrompt,{exact:true}).waitFor();assert.equal(await controlPage.locator('.approval-card').count(),0,'The actual follow-up conversation must not show the repeated-approval card seen in the user report');
    const [followupRows]=await pool.execute('SELECT status,computer_used AS computerUsed FROM agent_runs WHERE id=?',[followup.id]) as [Array<{status:string;computerUsed:number|boolean}>,unknown];
    assert.equal(followupRows[0]?.status,'completed');assert.ok(Boolean(followupRows[0]?.computerUsed),'The follow-up must actually use the isolated K3D computer');
   }
  }
  const inspectResponse=await workerRequest('/v1/guarded/snapshot-image');assert.equal(inspectResponse.status,200);const page=await inspectResponse.json() as {url?:string};assert.ok(page.url,'The real cloud computer must expose its current page');
  const pageHost=new URL(page.url).hostname;if(computerUiOnly)assert.equal(pageHost,'example.com');else assert.ok(['mail.google.com','accounts.google.com'].includes(pageHost),`Expected Gmail or Google sign-in page, got ${pageHost}`);
  desktopObserver=await chromium.connectOverCDP(`http://127.0.0.1:${cdpPort}`);const desktopContext=desktopObserver.contexts()[0];assert.ok(desktopContext,'The isolated Chromium desktop must expose its real CDP browser context');const originalDesktopPage=desktopContext.pages().find(candidate=>{try{return new URL(candidate.url()).hostname===pageHost}catch{return false}});assert.ok(originalDesktopPage,`The real desktop must expose its initial ${pageHost} tab to the read-only E2E observer`);
  const beforeHandoff=await workerRequest('/v1/guarded/control'),beforeOwner=await beforeHandoff.json() as {owner?:string};assert.equal(beforeOwner.owner,'agent');
  const computerButton=controlPage.getByRole('button',{name:`Open ${bot.name}'s computer`,exact:true});try{await computerButton.waitFor({timeout:10_000})}catch{const uiState=await controlPage.evaluate(()=>({url:location.href,title:document.title,body:document.body?.innerText.slice(0,2000),buttons:Array.from(document.querySelectorAll('button')).slice(0,40).map(button=>({text:button.innerText,ariaLabel:button.getAttribute('aria-label')}))})),screenshotPath=join(tmpdir(),`grok-computer-ui-${randomUUID()}.png`);await controlPage.screenshot({path:screenshotPath});throw new Error(`Grok Bot UI did not render the selected Bot's computer control; ui=${JSON.stringify(uiState)}; console=${JSON.stringify(uiErrors.slice(-10))}; screenshot=${screenshotPath}`)}
  await computerButton.click();await controlPage.getByRole('button',{name:'Open screen'}).click();const takeControlButton=controlPage.getByRole('button',{name:'Take control',exact:true});try{await takeControlButton.waitFor({timeout:15_000})}catch{const uiState=await controlPage.evaluate(()=>({body:document.body?.innerText.slice(-1500),screenStatus:document.querySelector('.computer-screen-status')?.textContent,dialogs:Array.from(document.querySelectorAll('[role="dialog"]')).map(dialog=>dialog.getAttribute('aria-label'))})),screenshotPath=join(tmpdir(),`grok-computer-takeover-${randomUUID()}.png`);await controlPage.screenshot({path:screenshotPath});throw new Error(`Grok Bot computer panel did not expose Take control; ui=${JSON.stringify(uiState)}; console=${JSON.stringify(uiErrors.slice(-10))}; screenshot=${screenshotPath}`)}await takeControlButton.click();await controlPage.getByRole('button',{name:'Return to Bot',exact:true}).waitFor({timeout:10_000});const chatComposer=controlPage.locator('.composer textarea');assert.equal(await chatComposer.evaluate(element=>element.closest('[inert]')!==null),true,'The external chat composer must be inert while the cloud computer takeover dialog is open');const composerRect=await chatComposer.boundingBox();assert.ok(composerRect,'The chat composer should remain laid out behind the takeover view');const composerCenter={x:composerRect.x+composerRect.width/2,y:composerRect.y+composerRect.height/2};assert.equal(await controlPage.evaluate(({x,y})=>Boolean(document.elementFromPoint(x,y)?.closest('.computer-screen-overlay')) ,composerCenter),true,'The full-screen takeover layer must visually cover the external chat composer, not merely disable its input');await chatComposer.evaluate(element=>(element as HTMLTextAreaElement).focus());assert.equal(await controlPage.locator('.computer-screen-dialog').evaluate(dialog=>dialog.contains(document.activeElement)),true,'Focus must stay inside the computer dialog during takeover');const afterHandoff=await workerRequest('/v1/guarded/control'),afterOwner=await afterHandoff.json() as {owner?:string};assert.equal(afterOwner.owner,'user','The product UI Take control button must transfer the real K3D computer to the signed-in owner');
  const remoteFrame=controlPage.frameLocator(`iframe[title="Mediated Bot cloud computer"]`);await remoteFrame.locator('#status[data-state="connected"]').waitFor({timeout:30_000});await remoteFrame.locator('canvas').first().waitFor({timeout:30_000});
  // Xfce may put a separate window titlebar above Chromium. Check both observed
  // tab/address rows and accept a click only after the real selected URL or
  // browser-focus state confirms it landed in Chrome's browser chrome.
  const addressBarYs=(height:number)=>[height*.1,height*.13];const fullScreenTabBarYs=(height:number)=>[height*.05,height*.083],fullScreenAddressBarYs=(height:number)=>[height*.1,height*.13];const remoteCanvas=remoteFrame.locator('#viewport canvas').first();const canvasBounds=await remoteCanvas.boundingBox();assert.ok(canvasBounds&&canvasBounds.width>=640&&canvasBounds.height>=480,'The embedded noVNC canvas must occupy a usable area');await remoteCanvas.click({position:{x:canvasBounds.width*.5,y:canvasBounds.height*.1}});await sleep(250);const clickFocusResponse=await workerRequest('/v1/guarded/snapshot-image');assert.equal(clickFocusResponse.status,200);const clickFocusSnapshot=await clickFocusResponse.json() as {image?:string;url?:string};const clickFocusScreenshotPath=join(tmpdir(),`grok-noVNC-click-focus-${randomUUID()}.png`);if(clickFocusSnapshot.image)await writeFile(clickFocusScreenshotPath,Buffer.from(clickFocusSnapshot.image,'base64'));const focusedWindow=(await run('kubectl',['-n',namespace,'exec',desktopPodName,'-c','desktop','--','xdotool','getwindowfocus'])).trim();assert.match(focusedWindow,/^\d+$/);const focusTitle=await run('kubectl',['-n',namespace,'exec',desktopPodName,'-c','desktop','--','xdotool','getwindowname',focusedWindow]);const focusGeometry=await run('kubectl',['-n',namespace,'exec',desktopPodName,'-c','desktop','--','xdotool','getwindowgeometry','--shell',focusedWindow]);const focusWindowInfo=await run('kubectl',['-n',namespace,'exec',desktopPodName,'-c','desktop','--','xwininfo','-id',focusedWindow,'-all']);await remoteFrame.locator('#viewport').evaluate(element=>{const frameWindow=element.ownerDocument.defaultView as (Window&{__cokeKeyEvents?:Array<{key:string;code:string;ctrl:boolean;shift:boolean}>})|null;if(!frameWindow)return;frameWindow.__cokeKeyEvents=[];frameWindow.addEventListener('keydown',event=>frameWindow.__cokeKeyEvents?.push({key:event.key,code:event.code,ctrl:event.ctrlKey,shift:event.shiftKey}),true)});await sleep(500);
  const vncViewportResponse=await workerRequest('/v1/guarded/viewport'),vncViewport=await vncViewportResponse.json() as {left:number;top:number;width:number;height:number};assert.equal(vncViewportResponse.status,200);
  const desktopPod=desktopPodName,pointerLocation=await run('kubectl',['-n',namespace,'exec',desktopPod,'-c','desktop','--','xdotool','getmouselocation','--shell']);
   const targetHost='example.org',targetMarker=`grok-computer-tab-e2e=${randomUUID()}`,targetUrl=`https://${targetHost}/?${targetMarker}`;let selectedTabMarker=targetMarker;
   const initialMarker=`grok-computer-tab-initial-e2e=${randomUUID()}`;
   {const initialUrl=`https://example.com/?${initialMarker}`;await remoteCanvas.press('Control+l');await sleep(250);await remoteCanvas.press('Control+a');await sleep(100);await remoteCanvas.type(initialUrl,{delay:180});await sleep(300);await remoteCanvas.press('Enter');let initialNavigation=false;for(let i=0;i<30;i++){if(originalDesktopPage.url().includes(initialMarker)){initialNavigation=true;break}await sleep(500)}assert.equal(initialNavigation,true,`The owner must first navigate the original tab to the same-title fixture; current URL: ${originalDesktopPage.url()}`);}
   const initialDesktopPages=desktopContext.pages();let userOpenedTab:Page|undefined;await remoteCanvas.press('Control+t');for(let i=0;i<30&&!userOpenedTab;i++){userOpenedTab=desktopContext.pages().find(candidate=>!initialDesktopPages.includes(candidate));if(!userOpenedTab)await sleep(100)}assert.ok(userOpenedTab,'The owner must be able to open a real second tab in cloud Chromium');const createdTab=userOpenedTab;const expectedTabCount=initialDesktopPages.length+1;assert.equal(desktopContext.pages().length,expectedTabCount,'Ctrl+T must create exactly one real tab');const tabBarX=(index:number,width:number)=>width*Math.min(.82,.11+.165*index);assert.ok(desktopContext.pages().includes(createdTab),'The newly created Chrome tab must remain present');await remoteCanvas.click({position:{x:canvasBounds.width*.75,y:canvasBounds.height*.8}});assert.equal(await createdTab.evaluate(()=>document.hasFocus()),true,'Clicking the webpage must focus page content before testing the address-bar mouse click');const modalAddressBarAttempts:Array<{ratio:number;pageHasFocus:boolean;pointer:string}>=[];for(const y of addressBarYs(canvasBounds.height)){await remoteCanvas.click({position:{x:canvasBounds.width*.5,y}});await sleep(150);const pageHasFocus=await createdTab.evaluate(()=>document.hasFocus());const pointer=await run('kubectl',['-n',namespace,'exec',desktopPodName,'-c','desktop','--','xdotool','getmouselocation','--shell']);modalAddressBarAttempts.push({ratio:y/canvasBounds.height,pageHasFocus,pointer})}await remoteCanvas.press('Control+a');typingIntoAddressBar=true;try{await remoteCanvas.type(targetUrl,{delay:180})}finally{typingIntoAddressBar=false}assert.ok(screenshotPollsDuringTyping.length>0,'The integrated screenshot poll must complete while the owner types into the second tab address bar');await remoteCanvas.press('Enter');
  let userOpenedTabUrl='',selectedTabScreenshotUrl='';for(let i=0;i<60;i++){const matchingPage=desktopContext.pages().find(candidate=>candidate===createdTab&&candidate.url().includes(targetMarker));const snapshotResponse=await workerRequest('/v1/guarded/snapshot-image');if(snapshotResponse.status===200){const snapshot=await snapshotResponse.json() as {url?:string};selectedTabScreenshotUrl=snapshot.url||''}if(matchingPage&&matchingPage.url().includes(targetMarker)&&selectedTabScreenshotUrl.includes(targetMarker)){userOpenedTab=matchingPage;userOpenedTabUrl=matchingPage.url();break}await sleep(500)}
  if(!userOpenedTabUrl){const screenshotPath=join(tmpdir(),`grok-noVNC-input-${randomUUID()}.png`),current=await workerRequest('/v1/guarded/snapshot-image');assert.equal(current.status,200);const currentSnapshot=await current.json() as {image?:string;url?:string};if(currentSnapshot.image)await writeFile(screenshotPath,Buffer.from(currentSnapshot.image,'base64'));const tabs=await Promise.all(desktopContext.pages().map(async candidate=>({url:candidate.url(),title:await candidate.title().catch(()=>''),wasInitiallyOpen:initialDesktopPages.includes(candidate),createdByCtrlT:candidate===createdTab})));throw new Error(`Owner-entered URL did not resolve in the selected Chrome tab; expected=${targetUrl}; workerScreenshotUrl=${selectedTabScreenshotUrl||'unknown'}; finalScreenshotUrl=${currentSnapshot.url||'unknown'}; tabs=${JSON.stringify(tabs)}; addressClicks=${JSON.stringify(modalAddressBarAttempts)}; screenshot=${currentSnapshot.image?screenshotPath:'unavailable'}`)}
  // The noVNC screenshot URL and the CDP page URL identify the visible target tab.
  // Do not infer visible tab order or identity from Playwright's pages() ordering.
  assert.equal(desktopContext.pages().length,expectedTabCount,'The address-bar interaction must not create an unintended extra tab');assert.ok(desktopContext.pages().includes(userOpenedTab),'The visible owner-navigated Chrome tab must remain present');
  const screenDialog=controlPage.locator('.computer-screen-dialog');
  await screenDialog.getByRole('button',{name:'Enter computer full screen'}).click();
  await controlPage.waitForFunction(()=>document.fullscreenElement===document.querySelector('.computer-screen-dialog'));
  const fullScreenCanvas=remoteFrame.locator('#viewport canvas').first();
  await remoteFrame.locator('#status[data-state="connected"]').waitFor({timeout:30_000});
  const fullScreenBounds=await fullScreenCanvas.boundingBox();
  assert.ok(fullScreenBounds&&fullScreenBounds.width>=640&&fullScreenBounds.height>=480,'The noVNC canvas must remain usable in full-screen mode');
  const screenshotPollsBeforeFullScreenTyping=screenshotPollsDuringTyping.length;
  const fullScreenMarker=`grok-computer-fullscreen-e2e=${randomUUID()}`,fullScreenUrl=`https://${targetHost}/?${fullScreenMarker}`;
  // Discover the visible tab positions by clicking through the real tab strip and
  // reading the selected page from the desktop screenshot stream. Playwright's
  // pages() order is not Chromium's left-to-right tab order.
  const fullScreenPages=desktopContext.pages();
  assert.ok(fullScreenPages.length>=2,'A different Chrome tab is required to verify full-screen tab switching');
  const readVisibleDesktopUrl=async()=>{const response=await workerRequest('/v1/guarded/snapshot-image');if(response.status!==200)return '';const snapshot=await response.json() as {url?:string};return snapshot.url||''};
  const tabSwitchObservations:Array<{index:number;x:number;url:string}>=[];
  let clickedAwayFromTarget=false;
  for(const y of fullScreenTabBarYs(fullScreenBounds.height)){
   for(let index=0;index<fullScreenPages.length;index++){
    const x=tabBarX(index,fullScreenBounds.width);
    await fullScreenCanvas.click({position:{x,y}});
    await sleep(700);
    const visibleUrl=await readVisibleDesktopUrl();
    tabSwitchObservations.push({index,x,url:visibleUrl});
    if(visibleUrl&&!visibleUrl.includes(targetMarker)){clickedAwayFromTarget=true;break}
   }
   if(clickedAwayFromTarget)break;
  }
  if(!clickedAwayFromTarget){const response=await workerRequest('/v1/guarded/snapshot-image');const snapshot=response.status===200?await response.json() as {url?:string;image?:string}:undefined;const screenshotPath=join(tmpdir(),`grok-noVNC-fullscreen-tab-switch-${randomUUID()}.png`);if(snapshot?.image)await writeFile(screenshotPath,Buffer.from(snapshot.image,'base64'));throw new Error(`A real tab-strip click in full-screen mode did not switch away from the owner-navigated tab; target=${targetMarker}; observations=${JSON.stringify(tabSwitchObservations)}; tabs=${JSON.stringify(await Promise.all(fullScreenPages.map(async page=>({url:page.url(),title:await page.title().catch(()=>''),width:fullScreenBounds.width,height:fullScreenBounds.height}))))}; screenshot=${snapshot?.image?screenshotPath:'unavailable'}`)}
  let clickedBackToTarget=false;
  for(const y of fullScreenTabBarYs(fullScreenBounds.height)){
   for(let index=0;index<fullScreenPages.length;index++){
    const x=tabBarX(index,fullScreenBounds.width);
    await fullScreenCanvas.click({position:{x,y}});
    await sleep(700);
    if((await readVisibleDesktopUrl()).includes(targetMarker)){clickedBackToTarget=true;break}
   }
   if(clickedBackToTarget)break;
  }
  assert.ok(clickedBackToTarget,'A real tab-strip click in full-screen mode must return to the owner-navigated tab');
  await sleep(200);
  let fullScreenScreenshotUrl='',fullScreenAddressFocused=false,fullScreenNavigated=false;
  const fullScreenAddressFocusAttempts:Array<{ratio:number;pageHasFocus:boolean}> = [];
  for(const y of fullScreenAddressBarYs(fullScreenBounds.height)){
   if(!(await readVisibleDesktopUrl()).includes(targetMarker)){
    let returnedToTarget=false;
    for(const tabY of fullScreenTabBarYs(fullScreenBounds.height)){
     for(let index=0;index<fullScreenPages.length;index++){
      await fullScreenCanvas.click({position:{x:tabBarX(index,fullScreenBounds.width),y:tabY}});
      await sleep(300);
      if((await readVisibleDesktopUrl()).includes(targetMarker)){returnedToTarget=true;break}
     }
     if(returnedToTarget)break;
    }
    assert.ok(returnedToTarget,'The target tab must be active before testing its full-screen address bar');
   }
   await fullScreenCanvas.click({position:{x:fullScreenBounds.width*.75,y:fullScreenBounds.height*.8}});
   assert.equal(await userOpenedTab.evaluate(()=>document.hasFocus()),true,'Clicking the full-screen webpage must restore page focus before testing its address-bar mouse click');
   await fullScreenCanvas.click({position:{x:fullScreenBounds.width*.5,y}});
   await sleep(150);
   const pageHasFocus=await userOpenedTab.evaluate(()=>document.hasFocus()).catch(()=>true);
   fullScreenAddressFocusAttempts.push({ratio:y/fullScreenBounds.height,pageHasFocus});
   // Chromium can keep document.hasFocus() true while the omnibox has focus.
   // The real navigation below is the authoritative proof that the mouse click
   // reached the address bar and accepted owner-entered text.
   fullScreenAddressFocused=true;
   await fullScreenCanvas.press('Control+a');
   typingIntoAddressBar=true;
   try{await fullScreenCanvas.type(fullScreenUrl,{delay:180})}finally{typingIntoAddressBar=false}
   await fullScreenCanvas.press('Enter');
   for(let i=0;i<30;i++){
    const matchingPage=desktopContext.pages().find(page=>page===createdTab&&page.url().includes(fullScreenMarker));
    const screenshotResponse=await workerRequest('/v1/guarded/snapshot-image');
    if(screenshotResponse.status===200){const snapshot=await screenshotResponse.json() as {url?:string};fullScreenScreenshotUrl=snapshot.url||''}
    if(matchingPage&&fullScreenScreenshotUrl.includes(fullScreenMarker)){userOpenedTab=matchingPage;fullScreenNavigated=true;break}
    await sleep(500);
   }
   if(fullScreenNavigated)break;
   fullScreenAddressFocused=false;
  }
  assert.ok(fullScreenAddressFocused,`A real address-bar click must take focus from the webpage in full-screen mode; attempts=${JSON.stringify(fullScreenAddressFocusAttempts)}`);
  if(!fullScreenNavigated||!userOpenedTab.url().includes(fullScreenMarker)||!fullScreenScreenshotUrl.includes(fullScreenMarker)){
   const response=await workerRequest('/v1/guarded/snapshot-image');
   const snapshot=response.status===200?await response.json() as {url?:string;image?:string}:undefined;
   const screenshotPath=join(tmpdir(),`grok-noVNC-fullscreen-failure-${randomUUID()}.png`);
   if(snapshot?.image)await writeFile(screenshotPath,Buffer.from(snapshot.image,'base64'));
   const tabs=await Promise.all(desktopContext.pages().map(async page=>({url:page.url(),title:await page.title().catch(()=>''),selected:page===userOpenedTab,original:page===originalDesktopPage})));
   throw new Error(`Full-screen noVNC navigation failed; expected=${fullScreenUrl}; workerScreenshotUrl=${fullScreenScreenshotUrl||'unknown'}; finalScreenshotUrl=${snapshot?.url||'unknown'}; addressFocus=${JSON.stringify(fullScreenAddressFocusAttempts)}; tabs=${JSON.stringify(tabs)}; fullScreenCanvas=${JSON.stringify(fullScreenBounds)}; screenshotPolls=${screenshotPollsDuringTyping.length-screenshotPollsBeforeFullScreenTyping}; screenshot=${snapshot?.image?screenshotPath:'unavailable'}`);
  }
  assert.ok(screenshotPollsDuringTyping.length>screenshotPollsBeforeFullScreenTyping,'The product screenshot stream must continue updating while the owner types in full-screen mode');
  selectedTabMarker=fullScreenMarker;
  const fullScreenSnapshotResponse=await workerRequest('/v1/guarded/snapshot-image');
  assert.equal(fullScreenSnapshotResponse.status,200);
  const fullScreenSnapshot=await fullScreenSnapshotResponse.json() as {image?:string;url?:string};
  const fullScreenScreenshotPath=join(tmpdir(),`grok-noVNC-fullscreen-success-${randomUUID()}.png`);
  if(fullScreenSnapshot.image)await writeFile(fullScreenScreenshotPath,Buffer.from(fullScreenSnapshot.image,'base64'));
  await screenDialog.getByRole('button',{name:'Exit computer full screen'}).click();
  await controlPage.waitForFunction(()=>document.fullscreenElement===null);
  await screenDialog.getByRole('button',{name:'Return to Bot',exact:true}).click();await screenDialog.getByRole('button',{name:'Take control',exact:true}).waitFor({timeout:10_000});
  const afterReturn=await workerRequest('/v1/guarded/control'),returnedOwner=await afterReturn.json() as {owner?:string};assert.equal(returnedOwner.owner,'agent','The product UI must return computer ownership to Pi');
  const returnedSnapshotResponse=await workerRequest('/v1/guarded/snapshot-image');assert.equal(returnedSnapshotResponse.status,200);const returnedSnapshot=await returnedSnapshotResponse.json() as {url?:string};assert.ok(returnedSnapshot.url,'The real desktop must remain inspectable after returning control to Pi');assert.equal(new URL(userOpenedTab.url()).hostname,targetHost,'The real second Chrome tab must remain navigated after control returns to Agent');assert.ok(userOpenedTab.url().includes(selectedTabMarker),'The owner-entered URL must persist in its own tab after modal and full-screen interaction');assert.equal(await userOpenedTab.title(),await originalDesktopPage.title(),'The owner-selected second tab and original tab must deliberately have the same title');
  const returnedInspectionResponse=await workerRequest('/v1/guarded/inspect');assert.equal(returnedInspectionResponse.status,200);const returnedInspection=await returnedInspectionResponse.json() as {url?:string;title?:string};const tabTopology=await Promise.all(desktopContext.pages().map(async candidate=>{let windowId:number|null=null;const cdp=await desktopContext.newCDPSession(candidate);try{windowId=(await cdp.send('Browser.getWindowForTarget')).windowId as number}catch{}finally{await cdp.detach().catch(()=>undefined)}const activity=await candidate.evaluate(()=>({visible:document.visibilityState==='visible',focused:document.hasFocus(),title:document.title})).catch(()=>({visible:false,focused:false,title:''}));let host='';try{host=new URL(candidate.url()).hostname}catch{}return {host,title:activity.title,visible:activity.visible,focused:activity.focused,windowId,selectedByOwner:candidate===userOpenedTab}}));const focusedWindowAfter=(await run('kubectl',['-n',namespace,'exec',desktopPodName,'-c','desktop','--','xdotool','getwindowfocus'])).trim();const focusedTitleAfter=(await run('kubectl',['-n',namespace,'exec',desktopPodName,'-c','desktop','--','xdotool','getwindowname',focusedWindowAfter])).trim();const focusedGeometryAfter=(await run('kubectl',['-n',namespace,'exec',desktopPodName,'-c','desktop','--','xdotool','getwindowgeometry','--shell',focusedWindowAfter])).trim();assert.equal(new URL(returnedInspection.url||'about:blank').hostname,targetHost,`Worker Browser User must resolve the selected desktop tab after return; worker=${JSON.stringify({url:returnedInspection.url,title:returnedInspection.title})}; visibleScreenshot=${fullScreenSnapshot.url||'unknown'}:${fullScreenScreenshotPath}; tabs=${JSON.stringify(tabTopology)}; x11=${JSON.stringify({title:focusedTitleAfter,geometry:focusedGeometryAfter})}`);
  await controlPage.getByRole('button',{name:'Close screen',exact:true}).click();assert.equal(await controlPage.locator('.composer textarea').evaluate(element=>element.closest('[inert]')!==null),false,'Closing the returned computer screen must restore the chat composer');
  if(!computerUiOnly){const verification=await submitFromComposer('Use computer_browser inspect to read the current page title and URL. Do not navigate, click, or use the terminal. Report the exact page title.');await scheduler.tick();const verificationRun=await awaitRun(bot.id,verification.id);assert.match(verificationRun.result||'',/\bExample Domain\b/i,'Pi must observe the page entered by the owner through the real desktop stream');const verificationApprovals=await fetch(`${base}/api/runs/${verification.id}/approvals`,{headers:{cookie:apiCookie}});assert.equal(((await verificationApprovals.json()) as {approvals:unknown[]}).approvals.length,0,'Read-only browser inspection after returning control must not create an approval');await controlPage.locator('.conversation').getByText('Use computer_browser inspect to read the current page title and URL. Do not navigate, click, or use the terminal. Report the exact page title.',{exact:true}).waitFor();}
  if(gmailHandoffOnly&&!computerUiOnly){const directNavigationWorker=new HttpGuardedComputerWorker(owner,bot.id,new URL(`http://desktop.${namespace}.svc.cluster.local:8082/`),identity.controlToken,randomUUID(),workerTransport),state=await directNavigationWorker.navigationState(AbortSignal.timeout(15_000));assert.equal(state.owner,'agent','The worker must own the computer before the scoped direct-navigation probe');const marker=`grok-authorized-navigation-${randomUUID()}`,url=`https://example.org/${marker}`,navigation=await directNavigationWorker.navigateIfUnchanged({kind:'browser',action:'navigate',url},state,AbortSignal.timeout(45_000)) as {ready?:unknown;url?:unknown};assert.equal(navigation.ready,true,'The guarded worker must complete an explicitly scoped navigation without screenshot capture');assert.equal(navigation.url,url,'The worker result must preserve the unique path while redacting query and fragment data');assert.ok(desktopContext.pages().some(page=>page.url()===url),'The real Chromium page must retain the exact path from the screenshot-free navigation');const navigated=await workerRequest('/v1/guarded/inspect'),navigatedState=await navigated.json() as {url?:string};assert.equal(navigatedState.url,url,'The real K3D browser must retain the navigation performed through the screenshot-free route');}
  await controlContext.close();await userControlBrowser.close();userControlBrowser=undefined;
  console.log(computerUiOnly?`Grok Bot embedded Computer UI and real K3D noVNC takeover passed: owner opened a second Chrome tab, entered URLs in modal and full-screen modes while ${screenshotPollsDuringTyping.length} screenshot poll(s) completed, returned control to Agent, and the chat composer was restored.`:`Product composer Gmail handoff E2E passed with real DeepSeek Pi and K3D: no approval cards, opened ${pageHost}, owner opened and navigated a second Chrome tab through Grok Bot noVNC in modal and full-screen modes, returned control to Agent, verified the scoped screenshot-free navigation route, and completed the Browser User check; model calls ${modelCalls}.`);
 }else{
 if(!memoryOnly){
 const submit=await fetch(path,{method:'POST',headers:{cookie:apiCookie,origin,'content-type':'application/json'},body:JSON.stringify({requestId,prompt:'Use computer_browser to inspect the current page. The Submit test button increments a counter, so click it exactly once and never click it again. After that, inspect the page and report success only if it says MEDIATED_CLICK_OK.'})});assert.equal(submit.status,200);const {run:task}=await submit.json() as {run:{id:string}};
 const fixture=`<!doctype html><title>Mediated test</title><button onclick="document.getElementById('result').textContent='MEDIATED_CLICK_OK '+(++window.clickCount)">Submit test</button><p id="result">Waiting</p><script>window.clickCount=0</script>`;
 await run('kubectl',['-n',namespace,'exec',pod,'-c','agent','--','node','-e',`const f=require('fs'),p='/workspace/tasks/${task.id}';f.mkdirSync(p,{recursive:true,mode:0o770});f.writeFileSync(p+'/fixture.html',${JSON.stringify(fixture)},{mode:0o664})`]);
 const snap=await workerRequest('/v1/guarded/snapshot-image');if(snap.status!==200)throw new Error(`Guarded snapshot HTTP ${snap.status}: ${(await snap.text()).slice(0,500)}`);const snapshot=await snap.json() as {owner:string;url:string;screenshotSha256:string;guardFingerprint:string;image:string},expected={owner:snapshot.owner,url:snapshot.url,screenshotSha256:snapshot.screenshotSha256,guardFingerprint:snapshot.guardFingerprint};const open=await workerRequest('/v1/guarded/execute',{expected,action:{kind:'browser',action:'open_artifact',taskId:task.id,path:'fixture.html'}});if(open.status!==200){const detail=(await open.text()).slice(0,300),afterResponse=await workerRequest('/v1/guarded/snapshot-image'),after=afterResponse.status===200?await afterResponse.json() as typeof snapshot:undefined,debugPrefix=join(tmpdir(),`grok-guard-diff-${randomUUID()}`);await writeFile(`${debugPrefix}-before.png`,Buffer.from(snapshot.image,'base64'));if(after)await writeFile(`${debugPrefix}-after.png`,Buffer.from(after.image,'base64'));throw new Error(`Guarded open-artifact HTTP ${open.status}: ${detail}; ownerSame=${after?.owner===expected.owner}; urlSame=${after?.url===expected.url}; screenshotSame=${after?.screenshotSha256===expected.screenshotSha256}; guardSame=${after?.guardFingerprint===expected.guardFingerprint}; screenshots=${debugPrefix}`)}await sleep(1500);
 scheduler=new RunScheduler(runs,executor,{concurrency:1,leaseSeconds:30});await scheduler.tick();let approved=0,status='';
 for(let i=0;i<220;i++){
  const list=await fetch(`${base}/api/runs/${task.id}/approvals`,{headers:{cookie:apiCookie}}),items=(await list.json() as {approvals:{id:string;status:string;action:string;hasScreenshot:boolean}[]}).approvals;
  for(const item of items.filter(x=>x.status==='pending')){
   const description=JSON.parse(item.action) as {kind:string;action:string;arguments:{target?:string};screenshotSha256:string};assert.equal(description.kind,'browser');assert.equal(description.action,'click');assert.equal(description.arguments.target,'Submit test');assert.equal(item.hasScreenshot,true);
   const screenshot=await fetch(`${base}/api/approvals/${item.id}/screenshot`,{headers:{cookie:apiCookie}});assert.equal(screenshot.status,200);assert.equal(screenshot.headers.get('content-type'),'image/png');assert.equal(createHash('sha256').update(Buffer.from(await screenshot.arrayBuffer())).digest('hex'),description.screenshotSha256);
   const before=await workerRequest('/v1/guarded/inspect'),view=await before.json() as {text?:string};assert.ok(view.text?.includes('Waiting'));assert.equal(view.text?.includes('MEDIATED_CLICK_OK'),false);
   const decision=await fetch(`${base}/api/approvals/${item.id}`,{method:'POST',headers:{cookie:apiCookie,origin,'content-type':'application/json'},body:JSON.stringify({decision:'approved'})});assert.equal(decision.status,200);approved++;
  }
  const result=await fetch(path,{headers:{cookie:apiCookie}}),rows=(await result.json() as {runs:{id:string;status:string}[]}).runs;status=rows.find(x=>x.id===task.id)?.status||'';if(['completed','failed','unknown'].includes(status))break;await sleep(1000);
 }
 if(status!=='completed')throw new Error(`Mediated Pi task did not complete: ${status}; approved ${approved}; model calls ${modelCalls}`);
 assert.equal(approved,1);const final=await workerRequest('/v1/guarded/inspect'),view=await final.json() as {text?:string};assert.ok(view.text?.includes('MEDIATED_CLICK_OK'));
 const eventResponse=await fetch(`${base}/api/runs/${task.id}/events`,{headers:{cookie:apiCookie}}),events=await eventResponse.json() as {events:{status:string}[]};assert.deepEqual(events.events.map(x=>x.status),['queued','running','completed']);
 await scheduler.stop();
 scheduler=new RunScheduler(runs,dshExecutor,{concurrency:1,leaseSeconds:30});
 const dshSubmit=await fetch(path,{method:'POST',headers:{cookie:apiCookie,origin,'content-type':'application/json'},body:JSON.stringify({requestId:randomUUID(),prompt:'For this task use only computer_desktop screenshot and computer_desktop click. Do not use computer_terminal, computer_files, or any shell command. Inspect the actual desktop, find the large green button, and click its visible center using coordinates from your screenshot. Coordinates use the full 1440x900 screenshot from its top-left, including Chromium and window-manager bars; do not subtract those bars. Wait for owner approval. Then use computer_browser inspect to confirm DSH_MEDIATED_CLICK_OK. Do not use computer_browser click. Report success only after you inspect the result.'})});assert.equal(dshSubmit.status,200);const {run:dshTask}=await dshSubmit.json() as {run:{id:string}};
 const dshFixture=`<!doctype html><title>DSH mediated computer</title><style>html,body{width:100%;height:100%;margin:0;background:#eef3f4;font:32px sans-serif}body{display:grid;place-items:center}button{width:620px;height:240px;border:0;border-radius:32px;background:#188b62;color:white;font-size:48px;font-weight:700}#result{position:fixed;top:40px;left:40px;font-weight:700}</style><p id="result">WAITING_FOR_DSH</p><button onclick="document.getElementById('result').textContent='DSH_MEDIATED_CLICK_OK'">Run DSH computer task</button>`;
 await run('kubectl',['-n',namespace,'exec',pod,'-c','agent','--','node','-e',`const f=require('fs'),p='/workspace/tasks/${dshTask.id}';f.mkdirSync(p,{recursive:true,mode:0o770});f.writeFileSync(p+'/dsh-computer.html',${JSON.stringify(dshFixture)},{mode:0o664})`]);
 const beforeDsh=await workerRequest('/v1/guarded/snapshot');assert.equal(beforeDsh.status,200);const openedDsh=await workerRequest('/v1/guarded/execute',{expected:await beforeDsh.json(),action:{kind:'browser',action:'open_artifact',taskId:dshTask.id,path:'dsh-computer.html'}});assert.equal(openedDsh.status,200);await sleep(1500);
 await scheduler.tick();let dshStatus='',dshApprovals=0,dshFailureResult='';const dshActionEvidence:{kind:string;action:string;arguments:Record<string,unknown>;visibleResult:boolean}[]=[];
 for(let i=0;i<240;i++){
  const list=await fetch(`${base}/api/runs/${dshTask.id}/approvals`,{headers:{cookie:apiCookie}}),items=(await list.json() as {approvals:{id:string;status:string;action:string;hasScreenshot:boolean}[]}).approvals;
  for(const item of items.filter(value=>value.status==='pending')){
   const description=JSON.parse(item.action) as {kind:string;action:string;arguments:{x?:number;y?:number};screenshotSha256:string};assert.equal(description.kind,'desktop');assert.equal(description.action,'click');assert.ok(Number.isInteger(description.arguments.x)&&Number.isInteger(description.arguments.y));assert.equal(item.hasScreenshot,true);
   const screenshot=await fetch(`${base}/api/approvals/${item.id}/screenshot`,{headers:{cookie:apiCookie}});assert.equal(screenshot.status,200);assert.equal(screenshot.headers.get('content-type'),'image/png');const screenshotBytes=Buffer.from(await screenshot.arrayBuffer());assert.equal(createHash('sha256').update(screenshotBytes).digest('hex'),description.screenshotSha256);await writeFile(join(dir,`dsh-computer-approval-${dshApprovals+1}.png`),screenshotBytes);
   const computerState=await workerRequest('/v1/guarded/inspect'),computerView=await computerState.json() as {text?:string};dshActionEvidence.push({kind:description.kind,action:description.action,arguments:description.arguments,visibleResult:Boolean(computerView.text?.includes('DSH_MEDIATED_CLICK_OK'))});
   if(dshApprovals>0){await fetch(`${base}/api/approvals/${item.id}`,{method:'POST',headers:{cookie:apiCookie,origin,'content-type':'application/json'},body:JSON.stringify({decision:'denied'})});throw new Error(`DSH requested a second computer mutation; actions ${JSON.stringify(dshActionEvidence)}`)}
   const decision=await fetch(`${base}/api/approvals/${item.id}`,{method:'POST',headers:{cookie:apiCookie,origin,'content-type':'application/json'},body:JSON.stringify({decision:'approved'})});assert.equal(decision.status,200);dshApprovals++;
  }
  const result=await fetch(path,{headers:{cookie:apiCookie}}),rows=(await result.json() as {runs:{id:string;status:string;result:string|null;diagnosticCode?:string|null}[]}).runs,found=rows.find(value=>value.id===dshTask.id);dshStatus=found?.status||'';if(dshStatus==='failed'||dshStatus==='unknown')dshFailureResult=safeDiagnostic(found?.result||found?.diagnosticCode||'');if(['completed','failed','unknown'].includes(dshStatus))break;await sleep(1000);
 }
 if(dshStatus!=='completed')throw new Error(`Mediated DSH task did not complete: ${dshStatus}; approved ${dshApprovals}; model calls ${modelCalls}; result=${dshFailureResult}`);
 assert.equal(dshApprovals,1);assert.ok(dshComputerScreenshots>0,'DSH must send a real cloud-computer screenshot to the model');assert.ok(dshComputerInspections>0,'DSH must inspect the actual Chromium page');const dshFinal=await workerRequest('/v1/guarded/inspect'),dshView=await dshFinal.json() as {text?:string};assert.ok(dshView.text?.includes('DSH_MEDIATED_CLICK_OK'));
 await scheduler.stop();scheduler=new RunScheduler(runs,executor,{concurrency:1,leaseSeconds:30});
 const piTerminalFile=`pi-terminal-${task.id}.txt`;
 const piTerminalSubmit=await fetch(path,{method:'POST',headers:{cookie:apiCookie,origin,'content-type':'application/json'},body:JSON.stringify({requestId:randomUUID(),prompt:`Use computer_terminal once to run exactly: printf 'PI_TERMINAL_OK' > ${piTerminalFile} in the shared directory. Wait for owner approval. Then use computer_files to read ${piTerminalFile} and report its exact contents.`})});assert.equal(piTerminalSubmit.status,200);const {run:piTerminalTask}=await piTerminalSubmit.json() as {run:{id:string}};
 await scheduler.tick();let piTerminalStatus='',piTerminalApprovals=0,piTerminalResult='';
 for(let i=0;i<180;i++){
  const list=await fetch(`${base}/api/runs/${piTerminalTask.id}/approvals`,{headers:{cookie:apiCookie}}),items=(await list.json() as {approvals:{id:string;status:string;action:string;hasScreenshot:boolean}[]}).approvals;
  for(const item of items.filter(value=>value.status==='pending')){
   const description=JSON.parse(item.action) as {kind:string;action:string;arguments:{command:string;directory:string};screenshotSha256:string};
   assert.equal(description.kind,'terminal');assert.equal(description.action,'run');assert.equal(description.arguments.directory,'shared');assert.ok(description.arguments.command.includes(piTerminalFile));assert.ok(item.hasScreenshot);
   const screenshot=await fetch(`${base}/api/approvals/${item.id}/screenshot`,{headers:{cookie:apiCookie}});assert.equal(screenshot.status,200);assert.equal(createHash('sha256').update(Buffer.from(await screenshot.arrayBuffer())).digest('hex'),description.screenshotSha256);
   assert.equal((await fetch(`${base}/api/approvals/${item.id}`,{method:'POST',headers:{cookie:apiCookie,origin,'content-type':'application/json'},body:JSON.stringify({decision:'approved'})})).status,200);piTerminalApprovals++;
  }
  const result=await fetch(path,{headers:{cookie:apiCookie}}),rows=(await result.json() as {runs:{id:string;status:string;message?:string;result?:string|null}[]}).runs,run=rows.find(value=>value.id===piTerminalTask.id);piTerminalStatus=run?.status||'';piTerminalResult=run?.result||run?.message||'';if(['completed','failed','unknown'].includes(piTerminalStatus))break;await sleep(1000);
 }
 if(piTerminalStatus!=='completed')throw new Error(`Mediated Pi terminal task did not complete: ${piTerminalStatus}; approvals ${piTerminalApprovals}; model calls ${modelCalls}; result=${piTerminalResult.slice(0,500)}`);
 assert.equal(piTerminalApprovals,1);assert.equal((await run('kubectl',['-n',namespace,'exec',pod,'-c','agent','--','cat',`/workspace/shared/${piTerminalFile}`])).trim(),'PI_TERMINAL_OK');
 await scheduler.stop();scheduler=new RunScheduler(runs,dshExecutor,{concurrency:1,leaseSeconds:30});
 const dshTerminalFile=`dsh-terminal-${dshTask.id}.txt`;
 const dshTerminalSubmit=await fetch(path,{method:'POST',headers:{cookie:apiCookie,origin,'content-type':'application/json'},body:JSON.stringify({requestId:randomUUID(),prompt:`Use computer_terminal once to run exactly: printf 'DSH_TERMINAL_OK' > ${dshTerminalFile} in the shared directory. Wait for owner approval. Then use computer_files to read ${dshTerminalFile} and report its exact contents.`})});assert.equal(dshTerminalSubmit.status,200);const {run:dshTerminalTask}=await dshTerminalSubmit.json() as {run:{id:string}};
 await scheduler.tick();let dshTerminalStatus='',dshTerminalApprovals=0,dshTerminalWriteApproved=false;
 for(let i=0;i<180;i++){
  const list=await fetch(`${base}/api/runs/${dshTerminalTask.id}/approvals`,{headers:{cookie:apiCookie}}),items=(await list.json() as {approvals:{id:string;status:string;action:string;hasScreenshot:boolean}[]}).approvals;
  for(const item of items.filter(value=>value.status==='pending')){
   const description=JSON.parse(item.action) as {kind:string;action:string;arguments:{command:string;directory:string};screenshotSha256:string};
   assert.equal(description.kind,'terminal');assert.equal(description.action,'run');assert.equal(description.arguments.directory,'shared');
   const command=description.arguments.command.trim();
   const writesTarget=command.includes(dshTerminalFile)&&command.includes('DSH_TERMINAL_OK');
   const safePreparation=/^(?:pwd|ls(?: -la|-al)?(?: \/workspace\/shared)?)$/.test(command);
   assert.ok(writesTarget||safePreparation,'DSH must request the exact sentinel write or a harmless workspace inspection');
   if(writesTarget)dshTerminalWriteApproved=true;
   assert.ok(item.hasScreenshot);
   const screenshot=await fetch(`${base}/api/approvals/${item.id}/screenshot`,{headers:{cookie:apiCookie}});assert.equal(screenshot.status,200);assert.equal(createHash('sha256').update(Buffer.from(await screenshot.arrayBuffer())).digest('hex'),description.screenshotSha256);
   assert.equal((await fetch(`${base}/api/approvals/${item.id}`,{method:'POST',headers:{cookie:apiCookie,origin,'content-type':'application/json'},body:JSON.stringify({decision:'approved'})})).status,200);dshTerminalApprovals++;
  }
  const result=await fetch(path,{headers:{cookie:apiCookie}}),rows=(await result.json() as {runs:{id:string;status:string}[]}).runs;dshTerminalStatus=rows.find(value=>value.id===dshTerminalTask.id)?.status||'';if(['completed','failed','unknown'].includes(dshTerminalStatus))break;await sleep(1000);
 }
 if(dshTerminalStatus!=='completed')throw new Error(`Mediated DSH terminal task did not complete: ${dshTerminalStatus}; approvals ${dshTerminalApprovals}; model calls ${modelCalls}`);
 assert.ok(dshTerminalApprovals>=1);assert.equal(dshTerminalWriteApproved,true,'DSH must request owner approval for the sentinel write');assert.equal((await run('kubectl',['-n',namespace,'exec',pod,'-c','agent','--','cat',`/workspace/shared/${dshTerminalFile}`])).trim(),'DSH_TERMINAL_OK');
 await scheduler.stop();scheduler=new RunScheduler(runs,executor,{concurrency:1,leaseSeconds:30});
 const interruptedFile=`interrupted-${randomUUID()}.txt`;
 const interruptSubmit=await fetch(path,{method:'POST',headers:{cookie:apiCookie,origin,'content-type':'application/json'},body:JSON.stringify({requestId:randomUUID(),prompt:`Use computer_terminal once to run exactly: sleep 8 && printf SHOULD_NOT_FINISH > ${interruptedFile} in the task directory. Wait for owner approval before starting it.`})});assert.equal(interruptSubmit.status,200);const {run:interruptTask}=await interruptSubmit.json() as {run:{id:string}};
 await scheduler.tick();let interruptApproval:{id:string}|undefined;
 for(let i=0;i<120&&!interruptApproval;i++){
  const list=await fetch(`${base}/api/runs/${interruptTask.id}/approvals`,{headers:{cookie:apiCookie}}),items=(await list.json() as {approvals:{id:string;status:string;action:string}[]}).approvals;
  const pending=items.find(value=>value.status==='pending');if(pending){const description=JSON.parse(pending.action) as {kind:string;action:string;arguments:{command:string;directory:string}};assert.equal(description.kind,'terminal');assert.equal(description.arguments.directory,'task');assert.ok(description.arguments.command.includes('sleep 8'));interruptApproval={id:pending.id};break;}
  await sleep(500);
 }
 assert.ok(interruptApproval,'Agent must request owner approval before starting a terminal command');
 assert.equal((await userPost('control',{owner:'agent'})).status,200);
 assert.equal((await fetch(`${base}/api/approvals/${interruptApproval.id}`,{method:'POST',headers:{cookie:apiCookie,origin,'content-type':'application/json'},body:JSON.stringify({decision:'approved'})})).status,200);
 await sleep(2000);assert.equal((await userPost('control',{owner:'user'})).status,200);
 let interruptedTerminalStatus='';for(let i=0;i<30;i++){const result=await fetch(path,{headers:{cookie:apiCookie}}),rows=(await result.json() as {runs:{id:string;status:string}[]}).runs;interruptedTerminalStatus=rows.find(value=>value.id===interruptTask.id)?.status||'';if(interruptedTerminalStatus==='unknown')break;await sleep(1000)}assert.equal(interruptedTerminalStatus,'unknown');
 await sleep(8000);const noLateWrite=await exec('kubectl',['-n',namespace,'exec',pod,'-c','agent','--','test','!','-e',`/workspace/tasks/${interruptTask.id}/${interruptedFile}`]);assert.equal(noLateWrite.code,0,'User takeover must kill an approved command before it can finish');
 assert.equal((await userPost('control',{owner:'agent'})).status,200);
 await scheduler.tick();await sleep(1000);const confirmed=await fetch(path,{headers:{cookie:apiCookie}}),confirmedRows=(await confirmed.json() as {runs:{id:string;status:string}[]}).runs;assert.equal(confirmedRows.find(value=>value.id===interruptTask.id)?.status,'unknown');
 const recovery=await fetch(`${base}/api/runs/${interruptTask.id}/recovery`,{method:'POST',headers:{cookie:apiCookie,origin,'content-type':'application/json'},body:JSON.stringify({decision:'acknowledge'})});assert.equal(recovery.status,200,'Owner must explicitly acknowledge the interrupted task before later runs can start');
 await scheduler.stop();scheduler=new RunScheduler(runs,executor,{concurrency:1,leaseSeconds:30});
 }
 if(memoryOnly)scheduler=new RunScheduler(runs,executor,{concurrency:1,leaseSeconds:30});
 if(!scheduler)throw new Error('Run scheduler was not configured for this test');
 const piMarker=`GROK_MEMORY_PI_${randomUUID().replaceAll('-','').slice(0,16)}`;
 const piMemorySave=await submitRun(bot.id,`Please remember this lasting preference for this Bot: when I ask for an acceptance marker, use exactly ${piMarker}. This is a synthetic test value, not a secret. Confirm after saving it. Do not use the computer.`);
 await scheduler.tick();const piMemorySaved=await awaitRun(bot.id,piMemorySave.id);assert.ok(piMemorySaved.result?.includes(piMarker));const [piMemoryRows]=await pool.execute('SELECT memory_text FROM bot_memories WHERE bot_id=? AND memory_text LIKE ?',[bot.id,`%${piMarker}%`]) as [Array<{memory_text:string}>,unknown];assert.ok(piMemoryRows.length>0,'Pi must persist the direct-user memory through bot_memory');
 await scheduler.stop();scheduler=new RunScheduler(runs,dshExecutor,{concurrency:1,leaseSeconds:30});
 const dshMarker=`GROK_MEMORY_DSH_${randomUUID().replaceAll('-','').slice(0,16)}`;
 const dshMemorySave=await submitRun(bot.id,`Please remember this lasting preference for this Bot: when I ask for a voice-output marker, use exactly ${dshMarker}. This is a synthetic test value, not a secret. Confirm after saving it. Do not use the computer.`);
 await scheduler.tick();const dshMemorySaved=await awaitRun(bot.id,dshMemorySave.id);assert.ok(dshMemorySaved.result?.includes(dshMarker));const [dshMemoryRows]=await pool.execute('SELECT memory_text FROM bot_memories WHERE bot_id=? AND memory_text LIKE ?',[bot.id,`%${dshMarker}%`]) as [Array<{memory_text:string}>,unknown];assert.ok(dshMemoryRows.length>0,'DSH must persist the direct-user memory through its plugin');
 await scheduler.stop();scheduler=new RunScheduler(runs,executor,{concurrency:1,leaseSeconds:30});
 const recall=await submitRun(bot.id,'What exact acceptance marker and voice-output marker did I ask you to remember for this Bot? Use only durable memory from earlier tasks; report both exact values and nothing else.');
 await scheduler.tick();const recalled=await awaitRun(bot.id,recall.id);assert.ok(recalled.result?.includes(piMarker)&&recalled.result?.includes(dshMarker),'Pi must recover both Pi- and DSH-written memories across tasks');
 const isolatedBot=await bots.create(session,{name:'Memory Isolation Bot',color:'#abcdef',shape:'round'}),isolatedRun=await submitRun(isolatedBot.id,'Use bot_memory to list this Bot’s saved memories. If this Bot has none, answer exactly EMPTY. Do not use another Bot’s conversation or memory.');
 await scheduler.tick();const isolatedResult=await awaitRun(isolatedBot.id,isolatedRun.id);assert.match(isolatedResult.result||'',/EMPTY|no saved memories|no memories/i);
 const [isolatedRows]=await pool.execute('SELECT id FROM bot_memories WHERE bot_id=?',[isolatedBot.id]) as [Array<{id:string}>,unknown];assert.equal(isolatedRows.length,0,'another Bot must not inherit the first Bot’s private memories');
 const groupSend=await fetch(`${base}/api/groups/${testGroup.id}/messages`,{method:'POST',headers:{cookie:apiCookie,origin,'content-type':'application/json'},body:JSON.stringify({requestId:randomUUID(),text:'Read the attached verification file.',targetBotIds:[bot.id],files:[uploadedGroupFile.id]})});assert.equal(groupSend.status,202);
 const groupView=(await groupSend.json() as {messages:{role:string;botId:string|null;status:string|null;files:RunFile[]}[]}).messages;
 const groupBotMessages=groupView.filter(message=>message.role==='bot');assert.equal(groupBotMessages.length,1);assert.equal(groupBotMessages[0].botId,bot.id);assert.equal(groupBotMessages[0].status,'queued');assert.deepEqual(groupBotMessages[0].files.map(file=>({id:file.id,kind:file.kind})),[{id:uploadedGroupFile.id,kind:'input'}]);
 await workspaceTransport.removeUpload(session,uploadedGroupFile.id,'txt',AbortSignal.timeout(30_000));
 console.log(memoryOnly?`Mediated Pi and DSH Bot Memory K3D tests passed with Bot isolation; model calls ${modelCalls}.`:`Mediated Pi and DSH K3D tests passed: separate Pods, real DeepSeek browser/desktop/terminal/shared-file tools, approval and takeover checks, plus persistent Pi/DSH Bot memory across runs and Bot isolation; model calls ${modelCalls}.`);
 }
}finally{await userControlBrowser?.close().catch(()=>undefined);await desktopObserver?.close().catch(()=>undefined);await scheduler?.stop();if(server)await new Promise<void>(resolve=>server!.close(()=>resolve()));for(const p of forwards)p.kill('SIGTERM');gateway?.close();if(gatewayServer)await new Promise<void>(resolve=>gatewayServer!.close(()=>resolve()));if(namespaceCreated)await exec('kubectl',['delete','namespace',namespace,'--wait=true','--timeout=90s'],undefined,100_000);await pool?.end();if(dbCreated)await admin?.query(`DROP DATABASE \`${db}\``);await admin?.end();await rm(dir,{recursive:true,force:true})}
